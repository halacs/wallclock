var searchData=
[
  ['write_180',['write',['../classace__routine_1_1Channel.html#ad7fa46d27162b4ec9ffa257f3881931d',1,'ace_routine::Channel::write()'],['../classace__routine_1_1Channel.html#a1134e9c905c7c0bb7255f208534355d8',1,'ace_routine::Channel::write(const T &amp;value)']]]
];
